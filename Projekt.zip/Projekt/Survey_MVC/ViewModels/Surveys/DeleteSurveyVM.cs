﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Survey_MVC.ViewModels.Surveys
{
    public class DeleteSurveyVM
    {
        public int surveyID { get; set; }
        public string surveyTitle { get; set; }
    }
}